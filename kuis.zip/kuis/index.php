<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>

<body>
    <div class="container">
    		<div class="row">
    			<h3>DAFTAR PENJUALAN</h3>
    		</div>
			<div class="row">
				<p>
					<a href="input.php" class="btn btn-success">Input Barang</a>
				</p>
				
				<table class="table table-striped table-bordered">
		              <thead>
		                <tr>
		                  <th>Kode</th>
		                  <th>Merk</th>
		                  <th>Harga</th>
		                  <th>Qty</th>
		                  <th>Action</th>
		                </tr>
		              </thead>
		              <tbody>
		              <?php 
					   include 'koneksi.php';
					   $pdo = Database::connect();
					   $sql = 'SELECT * FROM barang ORDER BY kode DESC';
	 				   foreach ($pdo->query($sql) as $row) {
						   		echo '<tr>';
							   	echo '<td>'. $row['kode'] . '</td>';
							   	echo '<td>'. $row['merk'] . '</td>';
							   	echo '<td>'. $row['harga'] . '</td>';
							   	echo '<td>'. $row['qty'] . '</td>';
							   	echo '<td width=250>';
							   	echo '<a class="btn" href="tampil.php?kode='.$row['kode'].'">Tampil</a>';
							   	echo ' ';
							   	echo '<a class="btn btn-success" href="update.php?kode='.$row['kode'].'">Update</a>';
							   	echo ' ';
							   	echo '<a class="btn btn-danger" href="hapus.php?kode='.$row['kode'].'">Hapus</a>';
							   	echo '</td>';
							   	echo '</tr>';
					   }
					   Database::disconnect();
					  ?>
				      </tbody>
	            </table>
    	</div>
    </div> <!-- /container -->
  </body>
</html>