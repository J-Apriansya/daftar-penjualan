<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>
<?php
    require 'koneksi.php';
 
    $kode = null;
    if ( !empty($_GET['kode'])) {
        $kode = $_REQUEST['kode'];
    }
     
    if ( null==$kode ) {
        header("Location: index.php");
    }
     
    if ( !empty($_POST)) {
        // keep track validation errors
        $kodeError = null;
        $merkError = null;
        $hargaError = null;
        $qtyError = null;
         
        // keep track post values
        $kode = $_POST['kode'];
        $merk = $_POST['merk'];
        $harga = $_POST['harga'];
        $qty = $_POST['qty'];
         
        // validate input
        $valid = true;
        if (empty($kode)) {
            $kodeError = 'silahkan masukan kode';
            $valid = false;
        }
         
        if (empty($merk)) {
            $emerkError = 'silahkan masukan merk';
            $valid = false;
        }
         
        if (empty($harga)) {
            $hargaError = 'silahkan masukan harga';
            $valid = false;
        }

        if (empty($qty)){
            $qtyError = 'silahkan masukan qty';
            $valid = false;
        }
         
        // update data
        if ($valid) {
            $pdo = Database::connect();
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $sql = "UPDATE barang  set kode = ?, merk = ?, harga = ?, qty = ? WHERE kode = ?";
            $q = $pdo->prepare($sql);
            $q->execute(array($kode,$merk,$harga,$qty,$kode));
            Database::disconnect();
            header("Location: index.php");
        }
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM barang where kode = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($kode));
        $data = $q->fetch(PDO::FETCH_ASSOC);
        $kode = $data['kode'];
        $merk = $data['merk'];
        $harga = $data['harga'];
        $qty = $data['qty'];
        Database::disconnect();
    }
?> 
<body>
    <div class="container">
     
                <div class="span10 offset1">
                    <div class="row">
                        <h3>Update daftar barang</h3>
                    </div>
             
                    <form class="form-horizontal" action="update.php?kode=<?php echo $kode?>" method="post">
                      <div class="control-group <?php echo !empty($kodeError)?'error':'';?>">
                        <label class="control-label">Kode</label>
                        <div class="controls">
                            <input name="kode" type="text"  placeholder="kode" value="<?php echo !empty($kode)?$kode:'';?>">
                            <?php if (!empty($kodeError)): ?>
                                <span class="help-inline"><?php echo $kodeError;?></span>
                            <?php endif; ?>
                        </div>
                      </div>
                      <div class="control-group <?php echo !empty($merkError)?'error':'';?>">
                        <label class="control-label">Merk</label>
                        <div class="controls">
                            <input name="merk" type="text" placeholder="merk" value="<?php echo !empty($merk)?$merk:'';?>">
                            <?php if (!empty($merkError)): ?>
                                <span class="help-inline"><?php echo $merkError;?></span>
                            <?php endif;?>
                        </div>
                      </div>
                      <div class="control-group <?php echo !empty($hargaError)?'error':'';?>">
                        <label class="control-label">Harga</label>
                        <div class="controls">
                            <input name="harga" type="text"  placeholder="harga" value="<?php echo !empty($harga)?$harga:'';?>">
                            <?php if (!empty($hargaError)): ?>
                                <span class="help-inline"><?php echo $hargaError;?></span>
                            <?php endif;?>
                        </div>
                      </div>
                      <div class="control-group <?php echo !empty($qtyError)?'error':'';?>">
                        <label class="control-label">Qty</label>
                        <div class="controls">
                            <input name="qty" type="text"  placeholder="qty" value="<?php echo !empty($qty)?$qty:'';?>">
                            <?php if (!empty($qtyError)): ?>
                                <span class="help-inline"><?php echo $qtyError;?></span>
                            <?php endif;?>
                        </div>
                      </div>

                      <div class="form-actions">
                          <button type="submit" class="btn btn-success">Update</button>
                          <a class="btn" href="index.php">Back</a>
                        </div>
                    </form>
                </div>
                 
    </div> <!-- /container -->
  </body>
</html>