<?php
    require 'koneksi.php';
    $kode = null;
    if ( !empty($_GET['kode'])) {
        $kode = $_REQUEST['kode'];
    }
     
    if ( null==$kode ) {
        header("Location: index.php");
    } else {
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "SELECT * FROM barang where kode = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($kode));
        $data = $q->fetch(PDO::FETCH_ASSOC);
        Database::disconnect();
    }
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>
 
<body>
    <div class="container">
     
                <div class="span10 offset1">
                    <div class="row">
                        <h3>Tampil Data Barang</h3>
                    </div>
                     
                    <div class="form-horizontal" >
                      <div class="control-group">
                        <label class="control-label">kode</label>
                        <div class="controls">
                            <label class="checkbox">
                                <?php echo $data['kode'];?>
                            </label>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label">merk</label>
                        <div class="controls">
                            <label class="checkbox">
                                <?php echo $data['merk'];?>
                            </label>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label">harga</label>
                        <div class="controls">
                            <label class="checkbox">
                                <?php echo $data['harga'];?>
                            </label>
                        </div>
                      </div>
                      <div class="control-group">
                        <label class="control-label">qty</label>
                        <div class="controls">
                            <label class="checkbox">
                                <?php echo $data['qty'];?>
                            </label>
                        </div>
                      </div>
                        <div class="form-actions">
                          <a class="btn" href="index.php">Back</a>
                       </div>
                     
                      
                    </div>
                </div>
                 
    </div> <!-- /container -->
  </body>
</html>