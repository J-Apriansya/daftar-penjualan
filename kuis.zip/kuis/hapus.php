<?php
    require 'koneksi.php';
    $kode = 0;
     
    if ( !empty($_GET['kode'])) {
        $kode = $_REQUEST['kode'];
    }
     
    if ( !empty($_POST)) {
        // keep track post values
        $kode = $_POST['kode'];
         
        // delete data
        $pdo = Database::connect();
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $sql = "DELETE FROM barang  WHERE kode = ?";
        $q = $pdo->prepare($sql);
        $q->execute(array($kode));
        Database::disconnect();
        header("Location: index.php");
         
    }
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>
 
<body>
    <div class="container">
     
                <div class="span10 offset1">
                    <div class="row">
                        <h3>Hapus</h3>
                    </div>
                     
                    <form class="form-horizontal" action="hapus.php" method="post">
                      <input type="hidden" name="kode" value="<?php echo $kode;?>"/>
                      <p class="alert alert-error">anda yakin ingin menghapus ?</p>
                      <div class="form-actions">
                          <button type="submit" class="btn btn-danger">Yes</button>
                          <a class="btn" href="index.php">No</a>
                        </div>
                    </form>
                </div>
                 
    </div> <!-- /container -->
  </body>
</html>